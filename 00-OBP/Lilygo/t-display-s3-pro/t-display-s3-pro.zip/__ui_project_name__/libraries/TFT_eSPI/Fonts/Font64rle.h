#include <Fonts/Font64rle.c>

#define nr_chrs_f64 96
#define chr_hgt_f64 48
#define baseline_f64 36
#define data_size_f64 8
#define firstchr_f64 32

extern const unsigned char widtbl_f64[96];
extern const unsigned char* const chrtbl_f64[96];
